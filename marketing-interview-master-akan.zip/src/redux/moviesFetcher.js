import axios from 'axios';

export default url =>
  axios(url, {
    timeout: 20000,
    headers: {
      'Cache-Control': 'no-cache',
    },
  })
    .then(response => {
      if (response.status === 200) {
        return response.data;
      }

      return Promise.reject(
        new Error(`Error fetching data: ${response.statusText}`)
      );
    })

    .catch(err => Promise.reject(err));
