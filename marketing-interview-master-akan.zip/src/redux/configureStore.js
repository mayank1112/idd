import { createStore, applyMiddleware, combineReducers } from 'redux';
import { composeWithDevTools } from 'redux-devtools-extension';

import moviesFetcher from './moviesFetcher';

import moviesReducer from './movies/reducer';
import movieReducer from './movie/reducer';
import moviesMiddleware from './movies/middleware';
import movieMiddleware from './movie/middleware';

const rootReducer = combineReducers({
  movies: moviesReducer,
  movie: movieReducer,
});

export default () => {
  const store = createStore(
    rootReducer,
    composeWithDevTools(
      applyMiddleware(
        moviesMiddleware(moviesFetcher),
        movieMiddleware(moviesFetcher)
      )
    )
  );

  if (process.env.NODE_ENV !== 'production' && module.hot) {
    module.hot.accept('./movies/reducer', () =>
      store.replaceReducer(moviesReducer)
    );
  }

  return store;
};
