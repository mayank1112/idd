export const FETCH_MOVIES = 'FETCH_MOVIES';
export const FETCH_MOVIES_PENDING = 'FETCH_MOVIES_PENDING';
export const FETCH_MOVIES_SUCCESS = 'FETCH_MOVIES_SUCCESS';
export const FETCH_MOVIES_ERROR = 'FETCH_MOVIES_ERROR';

export const fetchMovies = () => ({
  type: FETCH_MOVIES,
});

export const fetchMoviesPending = () => ({
  type: FETCH_MOVIES_PENDING,
});

export const fetchMoviesSuccess = data => ({
  type: FETCH_MOVIES_SUCCESS,
  payload: {
    data,
  },
});

export const fetchMoviesError = msg => ({
  type: FETCH_MOVIES_ERROR,
  payload: {
    msg,
  },
});
