import {
  FETCH_MOVIES,
  fetchMoviesPending,
  fetchMoviesSuccess,
  fetchMoviesError,
} from './actions';

const url =
  'https://api.themoviedb.org/3/discover/movie?api_key=c857fa67fba523ad3ce66df18e7ab279&language=en-US&sort_by=popularity.desc&include_adult=false&include_video=false&page=1';

export default moviesFetcher => ({ dispatch, getState }) => next => action => {
  if (action.type === FETCH_MOVIES) {
    if (getState().movies.movies.results) {
      return dispatch(fetchMoviesSuccess(getState().movies.movies));
    }
    dispatch(fetchMoviesPending());

    return moviesFetcher(url)
      .then(data => {
        dispatch(fetchMoviesSuccess(data));
      })
      .catch(err => {
        dispatch(fetchMoviesError(err.message));
      });
  }

  return next(action);
};
