import { fetchMoviesSuccess } from './actions';

import reducer from './reducer';

describe('Movie/Reducder', () => {
  it('should return default', () => {
    const state = { other: 'test1' };

    expect(reducer(state, { type: 'RANDOM' })).toEqual(state);
  });

  it('should dispatch fetchMoviesSuccess', () => {
    const state = {};
    const data = {
      page: 1,
      total_results: 10000,
      total_pages: 500,
      results: [
        {
          title: 'tittle1',
        },
      ],
    };

    expect(reducer(state, fetchMoviesSuccess(data))).toEqual({
      error: null,
      movies: {
        page: 1,
        results: [
          {
            title: 'tittle1',
          },
        ],
        total_pages: 500,
        total_results: 10000,
      },
      pending: false,
      success: true,
    });
  });
});
