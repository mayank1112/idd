import {
  FETCH_MOVIES_PENDING,
  FETCH_MOVIES,
  FETCH_MOVIES_SUCCESS,
  FETCH_MOVIES_ERROR,
} from './actions';

const initialState = {
  movies: {},
  pending: null,
  success: null,
  error: null,
};

export default (state = initialState, action) => {
  switch (action.type) {
  case FETCH_MOVIES:
    return {
      ...state,
      pending: null,
      error: null,
      success: null,
    };
  case FETCH_MOVIES_PENDING:
    return {
      ...state,
      pending: true,
      error: null,
      success: null,
    };
  case FETCH_MOVIES_SUCCESS:
    return {
      ...state,
      movies: action.payload.data,
      pending: false,
      error: null,
      success: true,
    };
  case FETCH_MOVIES_ERROR:
    return {
      ...state,
      pending: false,
      error: action.payload.msg,
      success: false,
    };

  default:
    return state;
  }
};
