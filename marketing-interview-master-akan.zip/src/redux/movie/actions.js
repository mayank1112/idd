export const FETCH_MOVIE = 'FETCH_MOVIE';
export const FETCH_MOVIE_PENDING = 'FETCH_MOVIE_PENDING';
export const FETCH_MOVIE_SUCCESS = 'FETCH_MOVIE_SUCCESS';
export const FETCH_MOVIE_ERROR = 'FETCH_MOVIE_ERROR';

export const fetchMovie = id => ({
  type: FETCH_MOVIE,
  payload: {
    id,
  },
});

export const fetchMoviePending = () => ({
  type: FETCH_MOVIE_PENDING,
});

export const fetchMovieSuccess = data => ({
  type: FETCH_MOVIE_SUCCESS,
  payload: {
    data,
  },
});

export const fetchMovieError = msg => ({
  type: FETCH_MOVIE_ERROR,
  payload: {
    msg,
  },
});
