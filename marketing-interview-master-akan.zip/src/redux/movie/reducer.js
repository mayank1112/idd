import {
  FETCH_MOVIE_PENDING,
  FETCH_MOVIE,
  FETCH_MOVIE_SUCCESS,
  FETCH_MOVIE_ERROR,
} from './actions';

const initialState = {
  movie: {},
  pending: null,
  success: null,
  error: null,
};

export default (state = initialState, action) => {
  switch (action.type) {
  case FETCH_MOVIE:
    return {
      ...state,
      pending: null,
      error: null,
      success: null,
    };
  case FETCH_MOVIE_PENDING:
    return {
      ...state,
      pending: true,
      error: null,
      success: null,
    };
  case FETCH_MOVIE_SUCCESS:
    return {
      ...state,
      movie: {
        ...state.movie,
        [action.payload.data.id]: action.payload.data,
      },
      pending: false,
      error: null,
      success: true,
    };
  case FETCH_MOVIE_ERROR:
    return {
      ...state,
      pending: false,
      error: action.payload.msg,
      success: false,
    };

  default:
    return state;
  }
};
