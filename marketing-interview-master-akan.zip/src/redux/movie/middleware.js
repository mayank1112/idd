import {
  FETCH_MOVIE,
  fetchMoviePending,
  fetchMovieSuccess,
  fetchMovieError,
} from './actions';

export default movieFetcher => ({ dispatch, getState }) => next => action => {
  if (action.type === FETCH_MOVIE) {
    const { id } = action.payload;

    if (getState().movie.movie[id]) {
      return dispatch(fetchMovieSuccess(getState().movie.movie[id]));
    }

    dispatch(fetchMoviePending());

    const url = `https://api.themoviedb.org/3/movie/${id}?api_key=65e043c24785898be00b4abc12fcdaae&language=en-US`;

    return movieFetcher(url)
      .then(data => {
        dispatch(fetchMovieSuccess(data));
      })
      .catch(err => {
        dispatch(fetchMovieError(err.message));
      });
  }

  return next(action);
};
