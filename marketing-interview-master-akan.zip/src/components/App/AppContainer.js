import { connect } from 'react-redux';

import { fetchMovies } from '../../redux/movies/actions';
import AppComponent from './AppComponent';

const mapStateToProps = state => {
  return {
    movies: state.movies.movies.results,
    pending: state.movies.pending,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    fetchMovies: () => dispatch(fetchMovies()),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(AppComponent);
