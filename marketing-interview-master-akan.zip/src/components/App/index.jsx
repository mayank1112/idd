import React from 'react';
import PropTypes from 'prop-types';

import AppContainer from './AppContainer';
import Layout from '../Layout';

const App = props => (
  <Layout>
    <AppContainer {...props} />
  </Layout>
);

App.propTypes = {
  props: PropTypes.shape({}),
};

App.defaultProps = {
  props: {},
};

export default App;
