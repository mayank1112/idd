import React, { useEffect, useCallback } from 'react';
import PropTypes from 'prop-types';

// const API_MOVIES =`https://api.themoviedb.org/3/discover/movie?api_key=c857fa67fba523ad3ce66df18e7ab279&language=en-US&sort_by=popularity.desc&include_adult=false&include_video=false&page=1`
// const API_MOVIE = `https://api.themoviedb.org/3/movie/${id}?api_key=65e043c24785898be00b4abc12fcdaae&language=en-US`
// const IMG_PATH = `https://image.tmdb.org/t/p/w300`

import Card from '../Card/Card';
import ProgressBar from '../ProgressBar';

import './AppComponent.scss';

const AppComponent = ({ fetchMovies, movies, history, pending }) => {
  const handleOnClick = id => {
    history.push(`/movie/${id}`);
  };

  const fetchMoviesCb = useCallback(() => {
    fetchMovies();
  }, [fetchMovies]);

  useEffect(() => {
    fetchMoviesCb();
  }, [fetchMoviesCb]);

  if (pending) {
    return <ProgressBar />;
  }

  return (
    <div className="AppComponent">
      {(movies || []).map(data => (
        <Card
          data={data}
          key={data.id}
          onMovieClick={id => handleOnClick(id)}
        />
      ))}
    </div>
  );
};

AppComponent.propTypes = {
  fetchMovies: PropTypes.func,
  movies: PropTypes.arrayOf(PropTypes.shape({})),
  history: PropTypes.shape(),
  pending: PropTypes.bool,
};

AppComponent.defaultProps = {
  fetchMovies: () => {},
  movies: [],
  history: {},
  pending: false,
};

export default AppComponent;
