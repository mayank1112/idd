import React from 'react';
import { shallow, mount } from 'enzyme';

import Card from '../Card/Card';
import AppComponent from './AppComponent';

describe('<AppComponent />', () => {
  it('renders without crashing', () => {
    const element = shallow(<AppComponent />);
    expect(element).toBeDefined();
  });

  it('renders default movies', () => {
    const movies = [
      {
        adult: false,
        backdrop_path: '/hO7KbdvGOtDdeg0W4Y5nKEHeDDh.jpg',
        id: 475557,
        original_language: 'en',
        original_title: 'Joker',
        overview: 'During the 1980s, ane and turn',
        popularity: 684.43,
        release_date: '2019-10-04',
        title: 'Joker',
        vote_average: 8.7,
      },
      {
        adult: false,
        backdrop_path: '/hO7KbdvGOtDdeg0W4Y5nKEHeDDh.jpg',
        id: 575557,
        original_language: 'en',
        original_title: 'Joker',
        overview: 'During the 1980s, ane and turn',
        popularity: 684.43,
        release_date: '2019-10-04',
        title: 'Joker',
        vote_average: 8.7,
      },
    ];
    const fetchMoviesSpy = jest.fn(() => Promise.resolve(movies));

    const element = mount(
      <AppComponent
        fetchMovies={fetchMoviesSpy}
        movies={movies}
        pending={false}
      />
    );

    expect(element.find(Card).length).toEqual(2);
  });
});
