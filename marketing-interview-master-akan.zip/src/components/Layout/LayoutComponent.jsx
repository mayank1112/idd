import React from 'react';
import PropTypes from 'prop-types';

import Paper from '@material-ui/core/Paper';

import './Layout.scss';

const LayoutComponent = ({ children }) => <Paper>{children}</Paper>;

LayoutComponent.propTypes = {
  children: PropTypes.arrayOf(PropTypes.element).isRequired,
};

export default LayoutComponent;
