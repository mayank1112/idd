import React from 'react';
import PropTypes from 'prop-types';

import LayoutComponent from './LayoutComponent';
import Header from '../Header/Header';
import Footer from '../Footer/Footer';

const Layout = ({ children }) => (
  <LayoutComponent>
    <Header />
    {children}
    <Footer />
  </LayoutComponent>
);

Layout.propTypes = {
  children: PropTypes.PropTypes.element.isRequired,
};

export default Layout;
