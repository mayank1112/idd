import React from 'react';
import Layout from './';

export default { title: 'Layout' };

export const withDiv = () => (
  <Layout>
    <div style={{ border: '1px solid #282828', padding: '10px 10px' }}>
      This is a content div
    </div>
  </Layout>
);
