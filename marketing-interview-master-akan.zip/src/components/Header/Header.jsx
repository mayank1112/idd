import React from 'react';

import './Header.scss';

const Header = () => (
  <div className="Header">
    <h2>Movies DB by Akan</h2>
    <p>
      Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
      tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
      veniam, quis nostrud ut aliquip ex ea commodo consequat.
    </p>

    <hr />
  </div>
);

export default Header;
