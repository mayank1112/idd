import React from 'react';
import moment from 'moment';
import PropTypes from 'prop-types';

import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardMedia from '@material-ui/core/CardMedia';
import CardContent from '@material-ui/core/CardContent';
import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import CardActions from '@material-ui/core/CardActions';
import Rating from '@material-ui/lab/Rating';
import { red } from '@material-ui/core/colors';

const useStyles = makeStyles(theme => ({
  card: {
    width: 345,
    margin: 10,
  },
  media: {
    height: 0,
    paddingTop: '56.25%', // 16:9
  },
  expand: {
    transform: 'rotate(0deg)',
    marginLeft: 'auto',
    transition: theme.transitions.create('transform', {
      duration: theme.transitions.duration.shortest,
    }),
  },
  expandOpen: {
    transform: 'rotate(180deg)',
  },
  avatar: {
    backgroundColor: red[500],
  },
}));

const MovieCard = ({ data, onMovieClick }) => {
  const classes = useStyles();
  const imgBase = 'https://image.tmdb.org/t/p/w300';
  const stars = data.vote_average ? data.vote_average / 2 : 0;

  return (
    <Card className={classes.card}>
      <CardHeader
        avatar={
          <Avatar aria-label="recipe" className={classes.avatar}>
            {data.adult ? '18+' : 'U'}
          </Avatar>
        }
        title={data.original_title}
        subheader={moment(data.release_date).format('LL')}
      />
      <CardMedia
        className={classes.media}
        image={`${imgBase}/${data.backdrop_path}`}
        title={data.original_title}
      />
      <CardContent>
        <Rating value={stars} readOnly size="small" />
        <Typography variant="body2" color="textSecondary" component="p">
          {data.overview}
        </Typography>
      </CardContent>
      <CardActions>
        <Button size="small" onClick={() => onMovieClick(data.id)}>
          Learn More
        </Button>
      </CardActions>
    </Card>
  );
};

MovieCard.propTypes = {
  data: PropTypes.shape(),
  onMovieClick: PropTypes.func.isRequired,
};

MovieCard.defaultProps = {
  data: {},
};

export default MovieCard;
