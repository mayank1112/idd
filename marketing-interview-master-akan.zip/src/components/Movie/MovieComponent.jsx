import React, { useEffect, useCallback } from 'react';
import PropTypes from 'prop-types';

import Rating from '@material-ui/lab/Rating';

import './MovieComponent.scss';
import ProgressBar from '../ProgressBar';

const MovieComponent = ({
  fetchMovie,
  movieId,
  movie,
  pending,
  error,
  success,
}) => {
  const fetchMovieCb = useCallback(() => {
    fetchMovie(movieId);
  }, [fetchMovie, movieId]);

  useEffect(() => {
    fetchMovieCb();
  }, [fetchMovieCb]);

  const imgBase = 'https://image.tmdb.org/t/p/w300';
  const stars = movie.vote_average ? movie.vote_average / 2 : 0;

  if (error) {
    return <h2 className="Movie-notfound">Not found: ${error}</h2>;
  }

  if (pending || !success) {
    return <ProgressBar />;
  }

  return (
    <div className="Movie">
      <div>
        {movie.backdrop_path && (
          <img
            className="Movie-image"
            alt={movie.original_title}
            src={`${imgBase}/${movie.backdrop_path}`}
          />
        )}
        <div className="clearfix">
          <Rating
            className="Movie-rating"
            value={stars}
            readOnly
            size="small"
          />
          <h4 className="Movie-content">{movie.original_title}</h4>
          <div className="Movie-content">{movie.overview}</div>
          <h4 className="Movie-content">Status: {movie.status}</h4>
        </div>
      </div>

      <div className="Movie-footer">
        <h4>Overview</h4>
        <p>{movie.tagline}</p>
      </div>
    </div>
  );
};

MovieComponent.propTypes = {
  fetchMovie: PropTypes.func,
  movieId: PropTypes.string,
  movie: PropTypes.shape({
    original_title: PropTypes.string,
    tagline: PropTypes.string,
    overview: PropTypes.string,
    backdrop_path: PropTypes.string,
    status: PropTypes.string,
    vote_average: PropTypes.number,
  }),
  pending: PropTypes.bool,
  success: PropTypes.bool,
  error: PropTypes.string,
};

MovieComponent.defaultProps = {
  fetchMovie: () => {},
  movieId: null,
  movie: {},
  pending: null,
  success: null,
  error: null,
};

export default MovieComponent;
