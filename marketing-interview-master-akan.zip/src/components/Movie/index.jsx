import React from 'react';
import PropTypes from 'prop-types';

import MovieContainer from './MovieContainer';
import Layout from '../Layout';

const Movie = props => (
  <Layout>
    <MovieContainer {...props} />
  </Layout>
);

Movie.propTypes = {
  props: PropTypes.shape({}),
};

Movie.defaultProps = {
  props: {},
};

export default Movie;
