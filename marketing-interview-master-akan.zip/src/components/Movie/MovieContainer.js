import { connect } from 'react-redux';

import { fetchMovie } from '../../redux/movie/actions';
import MovieComponent from './MovieComponent';

const mapStateToProps = (state, { match }) => {
  const {
    params: { id: movieId },
  } = match || {};

  return {
    movieId,
    movie: state.movie.movie[movieId] || {},
    pending: state.movie.pending,
    error: state.movie.error,
    success: state.movie.success,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    fetchMovie: id => dispatch(fetchMovie(id)),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(MovieComponent);
