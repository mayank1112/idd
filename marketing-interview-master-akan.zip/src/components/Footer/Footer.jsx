import React from 'react';
import { Link } from 'react-router-dom';

import './Footer.scss';

const Footer = () => (
  <div className="Footer">
    <h4>
      <Link to="/">Home</Link>
    </h4>
    <p>&copy; Movies DB - All rights reserved.</p>
  </div>
);

export default Footer;
